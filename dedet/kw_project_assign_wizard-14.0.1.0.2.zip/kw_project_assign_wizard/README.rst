Project task assign wizard
==========================

Wizard assign "Stage" or/and "Assign To" on selected tasks

This module is developed by the `KitWorks <https://kitworks.systems/>`__.
